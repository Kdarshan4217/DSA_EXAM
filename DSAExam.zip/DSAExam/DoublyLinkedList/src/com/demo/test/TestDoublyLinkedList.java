package com.demo.test;

import com.demo.linkedlist.DoublyLinkedList;

public class TestDoublyLinkedList {

	public static void main(String[] args) {
		DoublyLinkedList ob=new DoublyLinkedList();
		ob.addByposition(89, 1);
		ob.addByposition(66,2);
		ob.addByposition(44,3);
		ob.addByposition(30, 4);
		ob.addByposition(22, 5);
		ob.addByposition(11, 6);
		ob.addByposition(7, 7);

		ob.displayall();

	
		
		
		

	}

}
