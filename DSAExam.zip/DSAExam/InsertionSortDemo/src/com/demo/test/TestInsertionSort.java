package com.demo.test;
import java.util.Scanner;
import com.demo.sorting.InsertionSortdemo;

public class TestInsertionSort {

	public static void main(String[] args) {
//		char[] arr=new char[5];
//		InsertionSortdemo.acceptdata(arr);
//		InsertionSortdemo.displaydata(arr);
//		InsertionSortdemo.insertionsortascending(arr);
//		InsertionSortdemo.displaydata(arr);
		InsertionSortdemo st=new InsertionSortdemo ();
		Scanner sc=new Scanner(System.in);
         System.out.println("enter Character array size");
         int size=sc.nextInt();
         char[]arr =new char[size];
         int choice;
         do {
        	 System.out.println("1.insert data\n2.display sorted data\n3.exit\n\n enter choice:");
        	 choice=sc.nextInt();
        	 switch(choice) {
        	 
        	 case 1:st.acceptdata(arr);
        	 break;
        	 case 2:st.insertionsortascending(arr);
        	 break;
        	 case 3:
        		 System.out.println("thank you....");
        	 break;
        	 default:System.out.println("invalid choice...");
        	 break;
        	 }
         }while(choice!=3);
	}

		
}
