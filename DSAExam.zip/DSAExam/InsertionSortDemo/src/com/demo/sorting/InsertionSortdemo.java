package com.demo.sorting;

import java.util.Scanner;

public class InsertionSortdemo {

	public static void acceptdata(char[] arr) {
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<arr.length;i++) {
			System.out.println("enetr data");
			arr[i]=sc.next().charAt(0);
		}
		
	}
	
	public static void displaydata(char[] arr) {
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(i+"---->"+arr[i]);
			
		}
		System.out.println("------------------------------");
		
	}

	public static void insertionsortascending(char[] arr) {
		for(int i=1;i<arr.length;i++) {
			
			char key=arr[i]; 
		
			int j=i-1;
			while(j>=0 && arr[j]>key) {
				arr[j+1]=arr[j];
				j--;
			}
			arr[j+1]=key;
			displaydata(arr);
		}
		
	}
	

}

