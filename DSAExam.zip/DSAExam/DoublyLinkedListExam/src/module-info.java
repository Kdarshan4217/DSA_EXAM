/**
 * 
 */
/**
 * @author IET
 *
 */
module DoublyLinkedListExam {
}