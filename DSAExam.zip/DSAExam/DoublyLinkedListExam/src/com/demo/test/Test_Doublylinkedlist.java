package com.demo.test;
import com.demo.DoublyLinkedList;
public class Test_Doublylinkedlist {
	DoublyLinkedList ob = new DoublyLinkedList();
	ob.addByposition(23, 1);
	ob.addByposition(13,1);
	ob.addByposition(15,2 );
	ob.addByposition(25, 4);
	ob.displayall();
	ob.addByposition(21, 3);
	ob.addByposition(22, 2);
	ob.addByposition(45, 4);
	ob.displayall();
	ob.deletebypos(3);
	ob.displayall();
    ob.printrev();
	
	
}
}
