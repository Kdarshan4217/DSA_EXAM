package com.demo.doublylinkedlist;

public class DoublyLinkedList {

}
