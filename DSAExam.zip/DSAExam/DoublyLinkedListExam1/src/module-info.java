/**
 * 
 */
/**
 * @author IET
 *
 */
module DoublyLinkedListExam1 {
}