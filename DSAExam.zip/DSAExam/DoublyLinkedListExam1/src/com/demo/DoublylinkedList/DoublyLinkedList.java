package com.demo.DoublylinkedList;

import java.util.Scanner;

public class DoublyLinkedList {

	public Node head=null;
	class Node{
		int data;
		Node next;
		Node prev;
		public Node(int val) {
			data=val;
			next=null;
			prev=null;
		}
	}
	public void addByposition(int val, int pos) {
		
		Node newNode=new Node(val);
		
		if(head==null) {
			System.out.println("list is empty");
			head=newNode;
		}else {
			if(pos==1) {
				newNode.next=head;
				head.prev=newNode;
				head=newNode;
			}else {
				Node temp=head;
				for(int i=0;temp!=null && i<pos-2;i++) {
					temp=temp.next;
				}
				if(temp!=null) {
					newNode.next=temp.next;
					newNode.prev=temp;
					if(temp.next!=null) {
						temp.next.prev=newNode;
					}
					temp.next=newNode;
				}
			}
		}
		
	}
	
	public void displayReverseByPos(int pos) {
		Node temp=head;
		int count=0;
		while(temp!=null) {
			if(count==pos) {
				break;
			}
			temp=temp.next;
			count++;
		}
		
		if(temp!=null) {
			while(temp!=null) {
				System.out.println(temp.data+" ");
				temp=temp.prev;
			}
			System.out.println();		
		}else {
			System.out.println("Wrong Position...");
		}
	}

	public void displayAllData() {
		if(head==null) {
			System.out.println("list is empty");
		}else {
			for(Node temp=head;temp!=null;temp=temp.next) {
				System.out.print(temp.data+",");
			}
			System.out.println("\n-------------------\n");
		}
		
	}
}
























