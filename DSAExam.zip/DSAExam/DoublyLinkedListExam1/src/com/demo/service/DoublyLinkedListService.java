package com.demo.service;
import java.lang.*;
import java.util.Scanner;

import com.demo.DoublylinkedList.DoublyLinkedList;

public class DoublyLinkedListService {

	private DoublyLinkedList dll;
	
	public DoublyLinkedListService() {
		dll=new DoublyLinkedList();
	}
	Scanner sc=new Scanner(System.in);
	public void addData() {
		
		System.out.println("Enter Value: ");
		int val=sc.nextInt();
		System.out.println("Enter Position: ");
		int pos=sc.nextInt();
		
		dll.addByposition(val,pos);
		
	}

	public void displayDataPos() {
		
		System.out.println("Enter Position: ");
		int pos=sc.nextInt();
		
		dll.displayReverseByPos(pos);
		
	}

	public void displayData() {
		dll.displayAllData();
		
	}

	
	
}

