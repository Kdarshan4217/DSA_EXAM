package com.demo.test;

import java.util.Scanner;

import com.demo.service.DoublyLinkedListService;

public class TestDoubly {

	public static void main(String[] args) {
		DoublyLinkedListService dllService=new DoublyLinkedListService();
		int choice;
		do {
		Scanner sc=new Scanner(System.in);
		System.out.println("1.insert data by position\n2.DisplayAll \n3.display data from position\n4.exit\n\n Enter Choice:");
		choice=sc.nextInt();
		switch(choice) {
		case 1:
				dllService.addData();
				break;
		case 2:dllService.displayData();
				break;
		case 3:dllService.displayDataPos();
				break;
		case 4:System.out.println("Thank you..");
				break;
		default:System.out.println("Invalid Choice...");
			break;
		}
		}while(choice!=4);
	}

}
